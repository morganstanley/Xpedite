#!/usr/bin/env python2.7
#################################################################################
##
## Xpedite auto generated file
##
#################################################################################

import os
import sys
from xpedite import Probe, TxnBeginProbe, TxnEndProbe
from xpedite.pmu.event import Event
from xpedite.txn.classifier import ProbeDataClassifier
from xpedite import TopdownNode, Metric, Event, ResultOrder
sys.path.append(os.path.join(os.path.dirname(__file__), '../..'))
from allocatorAppRegular.parameters.profileInfo import *

############################################# Performance Counters #############################################
# List of performance counters to be collected for this profile
# The element can be one of 
#   1. Node in a topdown hierarchy
#   2. Metrics like IPC etc.
#   3. Raw hardware perforance counter for a micro architectural event
# To see topdown hierarchy run        - "xpedite topdown"
# To see available metrics run        - "xpedite metrics"
# To see available raw counters run   - "xpedite evlist"
pmc = [
  TopdownNode('Root'),         # top down analysis for Root node of the hierarchy
  Metric('IPC'),               # computer instructions retired per cycle mertric
  Event('kernel cycles',  'CPL_CYCLES.RING0'),
]
benchmarkPaths = None
