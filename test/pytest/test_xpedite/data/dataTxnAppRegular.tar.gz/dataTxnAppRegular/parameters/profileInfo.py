#!/usr/bin/env python2.7
#################################################################################
##
## Xpedite auto generated file
##
#################################################################################

import os
from xpedite import Probe, TxnBeginProbe, TxnSuspendProbe, TxnResumeProbe, TxnEndProbe
from xpedite.pmu.event import Event
from xpedite.txn.classifier import ProbeDataClassifier
from xpedite import TopdownNode, Metric, Event, ResultOrder

# Name of the application
appName = 'dataTxnApp'

# Host, where the applciation is running
appHost = 'localhost'

# Path of the appinfo file, configured in the application while initializing xpedite framework
appInfo = 'xpedite-appinfo.txt'

################################################## Probe List ##################################################
# Probes when enabled collect samples druing execution. The probes listed here are enabled during "xpedite record"
# Probes with types TxnBeginProbe and TxnEndProbe mark the beginning and end of transactions respectively. 
probes = [
  Probe('Byte Payload', sysName = 'BytePayload'),
  Probe('Byte Payload Begin', sysName = 'BytePayloadBegin'),
  Probe('Byte Payload End', sysName = 'BytePayloadEnd'),
  TxnBeginProbe('Data Scoped Txn Begin', sysName = 'DataScopedTxnBegin'),
  TxnEndProbe('Data Scoped Txn End', sysName = 'DataScopedTxnEnd'),
  TxnBeginProbe('Data Txn Begin', sysName = 'DataTxnBegin'),
  TxnEndProbe('Data Txn End', sysName = 'DataTxnEnd'),
  Probe('Double Quad Payload', sysName = 'DoubleQuadPayload'),
  Probe('Double Quad Payload Begin', sysName = 'DoubleQuadPayloadBegin'),
  Probe('Double Quad Payload End', sysName = 'DoubleQuadPayloadEnd'),
  Probe('Double Word Payload', sysName = 'DoubleWordPayload'),
  Probe('Double Word Payload Begin', sysName = 'DoubleWordPayloadBegin'),
  Probe('Double Word Payload End', sysName = 'DoubleWordPayloadEnd'),
  Probe('Probe Data Payload', sysName = 'ProbeDataPayload'),
  Probe('Probe Data Payload Begin', sysName = 'ProbeDataPayloadBegin'),
  Probe('Probe Data Payload End', sysName = 'ProbeDataPayloadEnd'),
  Probe('Quad Word Payload', sysName = 'QuadWordPayload'),
  Probe('Quad Word Payload Begin', sysName = 'QuadWordPayloadBegin'),
  Probe('Quad Word Payload End', sysName = 'QuadWordPayloadEnd'),
  Probe('Word Payload', sysName = 'WordPayload'),
  Probe('Word Payload Begin', sysName = 'WordPayloadBegin'),
  Probe('Word Payload End', sysName = 'WordPayloadEnd'),
]

benchmarkPaths = None
pmc = None
