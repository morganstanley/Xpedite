#!/usr/bin/env python2.7
#################################################################################
##
## Xpedite auto generated file
##
#################################################################################

import os
import sys
from xpedite import Probe, TxnBeginProbe, TxnSuspendProbe, TxnResumeProbe, TxnEndProbe
from xpedite.pmu.event import Event
from xpedite.txn.classifier import ProbeDataClassifier
from xpedite import TopdownNode, Metric, Event, ResultOrder
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from dataTxnApp_regular.profileInfo import *

############################################# Benchmark transactions ############################################
# List of stored reports from previous runs, to be used for benchmarking
# you can create, new benchmarks using --createBenchmark option to record or report sub-commands
benchmarkPaths = [
  '.'
]
